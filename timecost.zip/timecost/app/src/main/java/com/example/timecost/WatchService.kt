package com.example.timecost

import android.app.*
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.*
import android.widget.*
import java.util.Calendar
import kotlin.math.hypot

class WatchService : Service() {

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private var coin: CoinView? = null
    private var target: TextView? = null
    private var panel: LinearLayout? = null
    private var total = 0.0
    private var rows: List<Triple<String, Double, Long>> = emptyList() // name, cost, ms
    private val labels = HashMap<String, String>()
    private val dm get() = resources.displayMetrics
    private fun dp(v: Int) = (v * dm.density).toInt()
    private val launcher by lazy {
        packageManager.resolveActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME), 0)
            ?.activityInfo?.packageName ?: ""
    }

    private val tick = object : Runnable {
        override fun run() { refresh(); handler.postDelayed(this, 3000) }
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("tc", "Time Cost", NotificationManager.IMPORTANCE_LOW))
        startForeground(1, Notification.Builder(this, "tc")
            .setContentTitle("Time Cost coin is running")
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm).build())
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return START_NOT_STICKY }
        wm = getSystemService(WindowManager::class.java)
        if (coin == null) addCoin()
        handler.removeCallbacks(tick); handler.post(tick)
        return START_STICKY
    }

    override fun onDestroy() {
        handler.removeCallbacks(tick)
        hidePanel(); hideTarget()
        coin?.let { runCatching { wm.removeView(it) } }; coin = null
        super.onDestroy()
    }

    // ---------- Coin view ----------
    inner class CoinView(c: Context) : View(c) {
        var text = "₹0"
            set(v) { field = v; invalidate() }
        private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
        private val rim = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE; color = Color.parseColor("#B8860B"); strokeWidth = dp(4).toFloat() }
        private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE; color = Color.parseColor("#FFF3B0"); strokeWidth = dp(1).toFloat() }
        private val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#5D4037"); textAlign = Paint.Align.CENTER; typeface = Typeface.DEFAULT_BOLD }

        override fun onDraw(c: Canvas) {
            val r = width / 2f
            fill.shader = RadialGradient(r * 0.8f, r * 0.7f, r,
                Color.parseColor("#FFE082"), Color.parseColor("#FFB300"), Shader.TileMode.CLAMP)
            c.drawCircle(r, r, r - dp(2), fill)
            c.drawCircle(r, r, r - dp(2), rim)
            c.drawCircle(r, r, r - dp(7), ring)
            tp.textSize = dp(16).toFloat()
            while (tp.measureText(text) > width * 0.62f) tp.textSize -= 1f
            c.drawText(text, r, r - (tp.ascent() + tp.descent()) / 2, tp)
        }
    }

    private fun lp(w: Int, h: Int) = WindowManager.LayoutParams(
        w, h, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT)

    private fun addCoin() {
        val size = dp(64)
        val prefs = getSharedPreferences("cfg", MODE_PRIVATE)
        val p = lp(size, size).apply {
            gravity = Gravity.TOP or Gravity.START
            x = prefs.getInt("cx", dm.widthPixels - size); y = prefs.getInt("cy", dp(200))
        }
        val v = CoinView(this)
        var sx = 0; var sy = 0; var dx = 0f; var dy = 0f; var moved = false
        v.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = p.x; sy = p.y; dx = e.rawX; dy = e.rawY; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    val mx = e.rawX - dx; val my = e.rawY - dy
                    if (!moved && hypot(mx, my) > dp(8)) { moved = true; hidePanel(); showTarget() }
                    if (moved) {
                        p.x = (sx + mx).toInt(); p.y = (sy + my).toInt()
                        wm.updateViewLayout(v, p)
                        highlight(overTarget(p, size))
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) togglePanel()
                    else {
                        val hit = overTarget(p, size)
                        hideTarget()
                        if (hit) closeAll() else {
                            p.x = if (p.x + size / 2 < dm.widthPixels / 2) 0 else dm.widthPixels - size
                            wm.updateViewLayout(v, p)
                            prefs.edit().putInt("cx", p.x).putInt("cy", p.y).apply()
                        }
                    }
                }
            }
            true
        }
        wm.addView(v, p); coin = v
    }

    // ---------- Close target (bottom of screen) ----------
    private fun overTarget(p: WindowManager.LayoutParams, size: Int): Boolean {
        val cx = p.x + size / 2; val cy = p.y + size / 2
        return hypot((cx - dm.widthPixels / 2).toDouble(), (cy - (dm.heightPixels - dp(92))).toDouble()) < dp(90)
    }

    private fun showTarget() {
        if (target != null) return
        val t = TextView(this).apply {
            text = "✕"; textSize = 26f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.parseColor("#CC212121")) }
        }
        wm.addView(t, lp(dp(64), dp(64)).apply { gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL; y = dp(60) })
        target = t
    }

    private fun highlight(on: Boolean) {
        target?.apply {
            scaleX = if (on) 1.35f else 1f; scaleY = scaleX
            (background as GradientDrawable).setColor(Color.parseColor(if (on) "#E53935" else "#CC212121"))
        }
    }

    private fun hideTarget() { target?.let { runCatching { wm.removeView(it) } }; target = null }

    private fun closeAll() { stopForeground(STOP_FOREGROUND_REMOVE); stopSelf() }

    // ---------- App-wise panel ----------
    private fun togglePanel() { if (panel != null) hidePanel() else showPanel() }

    private fun hidePanel() { panel?.let { runCatching { wm.removeView(it) } }; panel = null }

    private fun showPanel() {
        val ll = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(16), dp(20), dp(16))
            background = GradientDrawable().apply { setColor(Color.parseColor("#F2212121")); cornerRadius = dp(20).toFloat() }
            setOnClickListener { hidePanel() }
        }
        wm.addView(ll, lp((dm.widthPixels * 0.82).toInt(), WindowManager.LayoutParams.WRAP_CONTENT)
            .apply { gravity = Gravity.CENTER })
        panel = ll; fillPanel()
    }

    private fun fillPanel() {
        val ll = panel ?: return
        ll.removeAllViews()
        fun row(a: String, b: String, sz: Float, col: Int) = LinearLayout(this).apply {
            setPadding(0, dp(5), 0, dp(5))
            addView(TextView(context).apply { text = a; textSize = sz; setTextColor(col) },
                LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            addView(TextView(context).apply { text = b; textSize = sz; setTextColor(col) })
        }
        ll.addView(row("Today's time cost", "₹${total.toInt()}", 18f, Color.parseColor("#FFC107")))
        rows.take(12).forEach { (n, cost, ms) ->
            ll.addView(row(n, "₹${cost.toInt()} · ${fmt(ms)}", 15f, Color.WHITE))
        }
        if (rows.isEmpty()) ll.addView(row("No usage yet", "", 15f, Color.LTGRAY))
    }

    // ---------- Usage calculation (all apps) ----------
    private fun refresh() {
        val usm = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val now = System.currentTimeMillis()
        val midnight = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }.timeInMillis

        val totals = HashMap<String, Long>()
        val starts = HashMap<String, Long>()
        val ev = usm.queryEvents(midnight, now)
        val e = UsageEvents.Event()
        while (ev.hasNextEvent()) {
            ev.getNextEvent(e)
            val p = e.packageName
            when (e.eventType) {
                UsageEvents.Event.ACTIVITY_RESUMED -> starts[p] = e.timeStamp
                UsageEvents.Event.ACTIVITY_PAUSED ->
                    starts.remove(p)?.let { totals[p] = (totals[p] ?: 0L) + (e.timeStamp - it) }
            }
        }
        starts.forEach { (p, s) -> totals[p] = (totals[p] ?: 0L) + (now - s) }

        val prefs = getSharedPreferences("cfg", MODE_PRIVATE)
        val hourly = prefs.getFloat("daily", 4000f) / prefs.getFloat("hours", 8f)
        val skip = setOf(packageName, "com.android.systemui", launcher)
        rows = totals.filter { it.key !in skip && it.value >= 30_000 }
            .map { Triple(label(it.key), it.value / 3_600_000.0 * hourly, it.value) }
            .sortedByDescending { it.second }
        total = rows.sumOf { it.second }
        coin?.text = if (total >= 1000) "₹%.1fk".format(total / 1000) else "₹${total.toInt()}"
        if (panel != null) fillPanel()
    }

    private fun label(p: String) = labels.getOrPut(p) {
        runCatching { packageManager.getApplicationLabel(packageManager.getApplicationInfo(p, 0)).toString() }
            .getOrDefault(p)
    }

    private fun fmt(ms: Long): String {
        val m = ms / 60000
        return if (m >= 60) "${m / 60}h ${m % 60}m" else "${m}m"
    }
}
