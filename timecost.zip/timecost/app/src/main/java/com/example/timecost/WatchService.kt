package com.example.timecost

import android.app.*
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView
import java.util.Calendar

class WatchService : Service() {

    // Add or remove apps here: package name -> display name
    private val watched = mapOf(
        "com.instagram.android" to "Instagram",
        "com.google.android.youtube" to "YouTube",
        "com.facebook.katana" to "Facebook",
        "com.twitter.android" to "X",
        "com.snapchat.android" to "Snapchat",
        "com.reddit.frontpage" to "Reddit"
    )
    private val repeatEveryMs = 5 * 60 * 1000L   // re-show popup every 5 min while app stays open

    private val handler = Handler(Looper.getMainLooper())
    private var lastFg: String? = null
    private var lastShown = 0L
    private var popup: TextView? = null

    private val tick = object : Runnable {
        override fun run() {
            check()
            handler.postDelayed(this, 3000)
        }
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("tc", "Time Cost", NotificationManager.IMPORTANCE_LOW))
        startForeground(1, Notification.Builder(this, "tc")
            .setContentTitle("Time Cost is watching")
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm).build())
        handler.removeCallbacks(tick); handler.post(tick)
        return START_STICKY
    }

    override fun onDestroy() { handler.removeCallbacks(tick); super.onDestroy() }

    private fun check() {
        val usm = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val now = System.currentTimeMillis()
        val midnight = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }.timeInMillis

        val totals = HashMap<String, Long>()
        val starts = HashMap<String, Long>()
        var fg: String? = null
        val ev = usm.queryEvents(midnight, now)
        val e = UsageEvents.Event()
        while (ev.hasNextEvent()) {
            ev.getNextEvent(e)
            val p = e.packageName
            when (e.eventType) {
                UsageEvents.Event.ACTIVITY_RESUMED -> { starts[p] = e.timeStamp; fg = p }
                UsageEvents.Event.ACTIVITY_PAUSED -> {
                    starts.remove(p)?.let { totals[p] = (totals[p] ?: 0L) + (e.timeStamp - it) }
                    if (fg == p) fg = null
                }
            }
        }
        starts.forEach { (p, s) -> totals[p] = (totals[p] ?: 0L) + (now - s) }

        val name = watched[fg]
        if (name != null && (fg != lastFg || now - lastShown > repeatEveryMs)) {
            val prefs = getSharedPreferences("cfg", MODE_PRIVATE)
            val hourly = prefs.getFloat("daily", 4000f) / prefs.getFloat("hours", 8f)
            val cost = (totals[fg] ?: 0L) / 3_600_000.0 * hourly
            show("₹${cost.toInt()} spent today on $name")
            lastShown = now
        }
        lastFg = fg
    }

    private fun show(msg: String) {
        if (!android.provider.Settings.canDrawOverlays(this)) return
        val wm = getSystemService(WindowManager::class.java)
        popup?.let { runCatching { wm.removeView(it) } }
        val tv = TextView(this).apply {
            text = msg; textSize = 20f; setTextColor(Color.WHITE)
            gravity = Gravity.CENTER; setPadding(48, 36, 48, 36)
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#D32F2F")); cornerRadius = 40f
            }
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; y = 200 }
        wm.addView(tv, lp)
        popup = tv
        handler.postDelayed({ runCatching { wm.removeView(tv) } }, 4000)
    }
}
