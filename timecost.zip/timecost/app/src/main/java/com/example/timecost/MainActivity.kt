package com.example.timecost

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("cfg", MODE_PRIVATE)

        fun input(hint: String, key: String, def: Float) = EditText(this).apply {
            this.hint = hint
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            setText(prefs.getFloat(key, def).toString())
        }
        fun button(text: String, onClick: () -> Unit) =
            Button(this).apply { this.text = text; setOnClickListener { onClick() } }

        val daily = input("Daily earning (₹)", "daily", 4000f)
        val hours = input("Working hours per day", "hours", 8f)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(48, 48, 48, 48)
            addView(TextView(context).apply { text = "⏱ Time Cost"; textSize = 26f })
            addView(daily); addView(hours)
            addView(button("1. Allow Usage Access") {
                startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
            })
            addView(button("2. Allow Display Over Other Apps") {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")))
            })
            addView(button("3. Save & Start") {
                prefs.edit()
                    .putFloat("daily", daily.text.toString().toFloatOrNull() ?: 4000f)
                    .putFloat("hours", hours.text.toString().toFloatOrNull() ?: 8f)
                    .apply()
                if (Build.VERSION.SDK_INT >= 33)
                    requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
                startForegroundService(Intent(this@MainActivity, WatchService::class.java))
                Toast.makeText(this@MainActivity, "Coin is on your screen. Drag it to the ✕ at the bottom to close.", Toast.LENGTH_LONG).show()
            })
        }
        setContentView(root)
    }
}
